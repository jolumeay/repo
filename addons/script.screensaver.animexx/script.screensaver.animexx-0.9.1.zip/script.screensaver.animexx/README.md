
# Animexx Fanarts
## an Fanart Screensave using Animexx

Feedreader will shows you the news and images from multiple rss feeds of your choice.

* [Author website](http://www.l0re.com/)


